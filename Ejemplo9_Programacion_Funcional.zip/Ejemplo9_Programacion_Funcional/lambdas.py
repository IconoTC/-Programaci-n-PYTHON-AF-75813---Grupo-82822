# Los lambdas son funciones anonimas
# se recomienda su uso cuando el cuerpo de la funcion es una sola linea
# Sintaxis: lambda parametros : cuerpo de la funcion

from persona import Persona
from functools import reduce

''' ************  map  ************ '''
# Ejemplo 1
numeros = [3,8,5,14,28]
numeros_dobles = list(map(lambda num: num * 2, numeros))
print(numeros_dobles)

# Ejemplo 2
alumnos = dict(Juan=6.4, Maria=8.3, Adolfo=7.1)
notas = dict(map(lambda item: (item[0], item[1] + 1), alumnos.items()))
print(notas)

# Ejemplo 3
personas = [Persona("Juan", 27), Persona("Maria", 15), Persona("Pedro", 21)]
personas = list(map(lambda person: Persona(person.nombre.upper(), person.edad + 1), personas))
for p in personas:
    print(p)
    
    
''' ************  filter  ************ '''
# Ejemplo 1
numeros = [3,8,5,14,28]
numeros_pares = list(filter(lambda num: num % 2 == 0 and num > 0, numeros))
print(numeros_pares)

# Ejemplo 2
alumnos = dict(Juan=3.4, Maria=8.3, Adolfo=7.1, Luis=4.4)
alumnos_suspensos = dict(filter(lambda item: item[1] < 5, alumnos.items()))
print(alumnos_suspensos)

# Ejemplo 3
personas = [Persona("Juan", 27), Persona("Maria", 15), Persona("Pedro", 21)]
personas_menores = list(filter(lambda persona: persona.edad < 18, personas))
for p in personas_menores:
    print(p)
    

''' ************  reduce  ************ '''
# Ejemplo 1
numeros = [3,8,5,14,28]
print("Suma:", reduce(lambda acumulado, num: acumulado + num, numeros))

# Ejemplo 2
nombres = ['Luis', 'Jorge', 'Maria', 'Laura', 'Pedro']
print(reduce(lambda acumulado, nombre: acumulado.upper() + " - " + nombre.upper(), nombres))