# La funcion filter se aplica sobre un coleccion
# a traves de otra funcion filtramos los elementos
# la funcion ha de devolver un valor booleano:
#       - True: pasa el filtro y nos lo quedamos
#       - False: no pasa el filtro y lo descartamos
# Sintaxis: filter(funcion, coleccion)

# Ejemplo 1
numeros = [3,8,5,14,28]

def pares(num):
    if num % 2 == 0:
        return True
    else:
        return False
    # return num % 2 == 0
    
numeros_pares = list(filter(pares, numeros))
print(numeros_pares)


# Ejemplo 2
alumnos = dict(Juan=3.4, Maria=8.3, Adolfo=7.1, Luis=4.4)

def suspensos(item):
    return item[1] < 5

alumnos_suspensos = dict(filter(suspensos, alumnos.items()))
print(alumnos_suspensos)


# Ejemplo 3
from persona import Persona            
personas = [Persona("Juan", 27), Persona("Maria", 15), Persona("Pedro", 21)]

def menores(persona):
    return persona.edad < 18

personas_menores = list(filter(menores, personas))
for p in personas_menores:
    print(p)