class Persona:
    def __init__(self, nombre:str, edad:int) -> None: 
        self.nombre = nombre
        self.edad = edad
    
    def __str__(self) -> str:
        return "Me llamo {} y tengo {} años".format(self.nombre, self.edad)