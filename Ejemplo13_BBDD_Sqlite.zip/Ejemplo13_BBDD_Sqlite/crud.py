import sqlite3

# Abrir la BBDD
conexion = sqlite3.connect("Ejemplo13_BBDD_Sqlite/tienda.db")

# Obtener un cursor
cursor = conexion.cursor()

''' ******************************* Insert  ********************************** '''
#cursor.execute("insert into PRODUCTOS values (1, 'Teclado', 129.95)")
#cursor.execute("insert into PRODUCTOS values (2, 'Scanner', 450.75)")

lista = [(3, 'Pantalla', 239.45), (4, 'Raton', 18.90), (5, 'Impresora', 89.90), (6, 'Auriculares', 230)]
sql = "insert into PRODUCTOS values (?, ?, ?)"
# cursor.executemany(sql, lista)

# IMPORTANTE EL COMMIT
conexion.commit()

''' ****************************** Consultas  ******************************** '''
# consultar todos los productos
cursor.execute("select * from PRODUCTOS")
productos = cursor.fetchall()   # recoge todos los resultados de la query
for prod in productos:
    print(prod)
print("--- FIN ---")

# consultar todos los productos con precio inferior a 50
cursor.execute("select * from PRODUCTOS where precio < 50")
productos = cursor.fetchall()  
for prod in productos:
    print(prod)
print("--- FIN ---")

# consultar todos los productos que sean Impresora
parametro = ('Impresora',)  # los parametros se pasan en tuplas
cursor.execute("select * from PRODUCTOS where descripcion = ?", parametro)
productos = cursor.fetchall()   # recoge todos los resultados de la query
for prod in productos:
    print(prod)
print("--- FIN ---")

# consultar todos los productos ordenados por precio ascendente
cursor.execute("select * from PRODUCTOS ORDER BY precio ASC")
productos = cursor.fetchall()   # recoge todos los resultados de la query
for prod in productos:
    print(prod)
print("--- FIN ---")

# consultar todos los productos ordenados por precio descendente
cursor.execute("select * from PRODUCTOS ORDER BY precio DESC")
productos = cursor.fetchall()   # recoge todos los resultados de la query
for prod in productos:
    print(prod)
print("--- FIN ---")

# consultar todos los productos que comienzan por la letra R
parametro = ('R%',)  # los parametros se pasan en tuplas
cursor.execute("select * from PRODUCTOS where descripcion LIKE ?", parametro)
productos = cursor.fetchall()   # recoge todos los resultados de la query
for prod in productos:
    print(prod)
print("--- FIN ---")

# consultar todos los productos que contiene por la letra e y el precio sea inferior a 200
parametro = ('%e%', 200)  # los parametros se pasan en tuplas
cursor.execute("select * from PRODUCTOS where descripcion LIKE ? and precio < ?", parametro)
productos = cursor.fetchall()   # recoge todos los resultados de la query
for prod in productos:
    print(prod)
print("--- FIN ---")

''' ****************************** Modificar ******************************** '''
# subir un 10% el precio de la impresora
parametro = ('Impresora',)
#cursor.execute("update PRODUCTOS set precio = precio * 1.1 where descripcion = ?", parametro)
conexion.commit()

''' ****************************** Eliminar ******************************** '''
# Eliminar todos los ratones
parametro = ('Raton',)
cursor.execute("delete from PRODUCTOS where descripcion = ?", parametro)
conexion.commit()

# cerrar la conexion
conexion.close()