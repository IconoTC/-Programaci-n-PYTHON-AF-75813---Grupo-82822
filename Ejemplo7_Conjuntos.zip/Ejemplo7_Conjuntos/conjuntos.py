# conjuntos: colecciones sin orden (no tenemos indices)
# No permite elementos duplicados, los ignora
# No se garantiza el orden de entrada de los elementos
# Los elementos pueden ser de diferentes tipos
# Se crean con {}
# IMPORTANTE: conjunto = {} lo interpreta como un diccionario

frutas = {'manzana', 'naranja', 'pera', 'naranja', 'platano'}
print(frutas)
print(type(frutas))  # <class 'set'>

# Conjunto vacio
conjunto = {}
print(type(conjunto))  # <class 'dict'>
conjunto = set()   # Llamo al constructor de la clase set
print(type(conjunto))  # <class 'set'>

# agregar elementos al conjunto
frutas.add("fresa")
print(frutas)

# Eliminar elemento
frutas.remove('platano')
print(frutas)

# Para recorrer conjuntos solo por item
for item in frutas:
    print(item, end=" ")
print()

# Copiar un conjunto en otro
# Funciona tambien con listas pero no con tuplas
otro = frutas.copy()
print(otro)

# Igual que listas y tuplas funciona los operadores de pertenencia: in y not in
print('manzana' in frutas)
print('melocoton' in frutas)
print('melocoton' not in frutas)

# Borrar todos los elementos
frutas.clear()
print(frutas)