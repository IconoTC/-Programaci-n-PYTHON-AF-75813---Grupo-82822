# try-except-else-finally

import traceback
try:
    numero1 = int(input("Introduce dividendo:"))
    numero2 = int(input("Introduce divisor:"))
    division = numero1 / numero2
except ValueError as ex:
    print("El valor introducido no es numerico")
    print(ex)  # Muestra el mensaje de la excepcion
    traceback.print_exc()  # Muestra la pila de llamadas
except ZeroDivisionError as pepito:
    print("No se puede dividir por cero")
    print(pepito)
except Exception as e:
    print("Ha ocurrido un error")
    print(type(e))
else:
    # Se ejecuta cuando no hay ningun error
    print("Resultado:", division)
finally:
    # Siempre se ejecuta, haya error o no
    print("****** FIN ******")
    
'''  Estructuras minimas  '''
try:
    pass
except:
    pass

try:
    pass
finally:
    pass

'''  El interprete de Python no lo reconoce
try:
    pass
else:
    pass
'''