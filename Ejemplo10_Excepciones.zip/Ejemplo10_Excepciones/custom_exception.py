'''  Crear una excepcion personalizada  '''

# Version minima
#class NegativoError(Exception):
#    pass

class NegativoError(Exception):
    def __init__(self, msg) -> None:
        self.message = msg
        
    def get_message(self):
        return self.message

try:
    edad = int(input("Introduce tu edad: "))
    if edad < 0:
        # Lanazamos la excepcion de forma manual
        raise NegativoError("La edad no puede ser negativa")
except NegativoError as ex:
    print(ex.get_message())