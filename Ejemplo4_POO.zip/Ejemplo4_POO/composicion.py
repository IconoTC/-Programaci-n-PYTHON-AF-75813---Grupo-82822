class Direccion:
    def __init__(self, calle: str, numero: int, poblacion: str) -> None:
        self.calle = calle
        self.numero = numero
        self.poblacion = poblacion
    
    # Sobreescribimos  el metodo __str__ heredado de la clase Object
    # Retorna una cadena de texto con la informacion del objeto
    def __str__(self) -> str:
        # Mayor, 5 (Madrid)
        return "{}, {} ({})".format(self.calle, self.numero, self.poblacion)   
    
    
# Composicion es cuando una clase tiene un atributo de otra clase
class Persona:
    def __init__(self, nombre:str, edad:int, direccion:Direccion = None) -> None: 
        self.nombre = nombre
        self.edad = edad
        self.direccion = direccion
    
    # Cuando el metodo recibe (self) se considera un metodo de instancia o dinamico
    def mostrar_info(self):
        if self.direccion:
            print("Me llamo {}, tengo {} años y vivo en {}".format(self.nombre, self.edad, self.direccion))
        else:
            print("Me llamo {} y tengo {} años".format(self.nombre, self.edad))
        
dirJuan = Direccion("Mayor", 5, "Madrid")        
p1 = Persona("Juan", 23, dirJuan)
p1.mostrar_info()

p2 = Persona("Maria", 42, Direccion("Diagonal", 124, "Barcelona"))
p2.mostrar_info()

p3 = Persona("Susana", 34)
p3.mostrar_info()

# Cambiar direccion de Juan a Castellana, 61, Madrid
# Modificar un objeto existente
p1.direccion.calle = "Castellana"
p1.direccion.numero = 61
p1.direccion.poblacion = "Madrid"
p1.mostrar_info()

# Aqui te creas un nuevo objeto
p1.direccion = Direccion("Castellana", 61, "Madrid")
p1.mostrar_info()