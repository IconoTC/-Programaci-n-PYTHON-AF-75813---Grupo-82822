class Persona:
    def __init__(self, nombre:str, edad:int) -> None: 
        self.nombre = nombre
        self.edad = edad
    
    def __str__(self) -> str:
        return "Me llamo {} y tengo {} años".format(self.nombre, self.edad)
    
class Empleado(Persona):
    def __init__(self, nombre: str, edad: int, sueldo: int) -> None:
        # Enviamos el nombre y la edad al constructor de la superclase
        super().__init__(nombre, edad)
        self.sueldo = sueldo
        
    def __str__(self) -> str:
        # super().__str__()  -> llama al __str__ de la superclase
        return "{}, sueldo {}".format(super().__str__(), self.sueldo)
    
class Jefe(Empleado):
    def __init__(self, nombre: str, edad: int, sueldo: int, bonus: int) -> None:
        super().__init__(nombre, edad, sueldo)
        self.bonus = bonus
        
    def __str__(self) -> str:
        #return "{}, bonus {}".format(super().__str__(), self.bonus)
        #return "{}, bonus {}".format(Empleado.__str__(self), self.bonus)
        return "{}, bonus {}".format(Persona.__str__(self), self.bonus)
    
    
# Crear objetos o instancias de Empleado
empl1 = Empleado("Juan", 23, 35000)
print(empl1)

jefe = Jefe("Jorge", 35, 50000, 12000)
print(jefe)