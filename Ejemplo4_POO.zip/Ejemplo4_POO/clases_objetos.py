class Persona:
    
    # constructor o inicializador
    def __init__(self, nombre:str, edad:int) -> None: # -> None, no retorna nada
        #pass  # significa que el cuerpo esta vacio
        # self.nombre y self.edad son atributos, campos, propiedades de la instancia de Persona
        self.nombre = nombre
        self.edad = edad
    
    # Cuando el metodo recibe (self) se considera un metodo de instancia o dinamico
    def mostrar_info(self):
        # El metodo necesita recibir el puntero self para acceder a los recursos de la instancia
        print("Me llamo", self.nombre, "y tengo", self.edad, "años")
        print("Me llamo {} y tengo {} años".format(self.nombre, self.edad))
        
        
# crear objetos o instancias de Persona
p1 = Persona("Juan", 23)

# Mostrar el objeto
print(p1)  # <__main__.Persona object at 0x106ab2240>
p1.mostrar_info()

# Los atributos o propiedades son publicas
p1.edad += 1
p1.mostrar_info()