'''
    Crear una clase Figura con propiedades: x, y
        metodo calcular_area (pass)
        metodo __str__ que retorne [x,y]
        
    Crear las clases Circulo, Triangulo, Rectangulo
    necesitareis nuevas propiedades
    sobreescribir el metodo calcular_area
    
    Crear instancias de cada figura y mostrar el area y __str__
'''

class Figura:
    def __init__(self, x, y) -> None:
        self.x = x
        self.y = y 
        
    def calcular_area(self):
        pass
    
    def __str__(self) -> str:
        #return "[{},{}]".format(self.x, self.y)
        return f"[{self.x},{self.y}]"
    
import math    
class Circulo(Figura):
    def __init__(self, x, y, radio) -> None:
        super().__init__(x, y)
        self.radio = radio
        
    def calcular_area(self):
        return math.pi * math.pow(self.radio, 2)
    

class Triangulo(Figura):
    def __init__(self, x, y, base, altura) -> None:
        super().__init__(x, y)
        self.base = base
        self.altura = altura
        
    def calcular_area(self):
        return self.base * self.altura / 2
    

class Rectangulo(Figura):
    def __init__(self, x, y, base, altura) -> None:
        super().__init__(x, y)
        self.base = base
        self.altura = altura
        
    def calcular_area(self):
        return self.base * self.altura
    
    
circulo = Circulo(10,5, 4.56)
print("Coordenadas del circulo:", circulo)
print("Area del circulo:", round(circulo.calcular_area(), 2))

triangulo = Triangulo(20,15, 100,50)
print("Coordenadas del triangulo:", triangulo)
print("Area del triangulo:", triangulo.calcular_area())

rectangulo = Rectangulo(15,23, 200,75)
print("Coordenadas del rectangulo:", rectangulo)
print("Area del rectangulo:", rectangulo.calcular_area())