def datos_trabajador(nombre, estado_civil="Soltero", sueldo=24000):
    print(nombre, "esta", estado_civil, "y gana", sueldo)
    
# En el momento que la funcion recibe mas de un argumento por defecto
# falla el pasar los datos por posicion
datos_trabajador("Maria")
#datos_trabajador("Juan", 35000)
datos_trabajador("Juan", sueldo=35000)
datos_trabajador(nombre="Juan", sueldo=35000)

'''
    En Python se pueden pasar los argumentos de 2 formas:
        - por posicion: datos_trabajador("Juan", 35000)
        - keywords: datos_trabajador(nombre="Juan", sueldo=35000)
'''

# Con keywords puedo cambiar el orden de los argumentos
datos_trabajador(sueldo=35000, nombre="Juan")
datos_trabajador(estado_civil="Casado", nombre="Antonio")


'''
    Crear una funcion que reciba:
        - datos como numero variable de argumentos
        - separador que por defecto sera " | "
    y retorne los datos unidos por el separador en una cadena de texto:  separador.join(datos)
'''
# En la combinacion: argumetos variables y argumentos por defecto
# El orden es 1º argumentos variables y luego por defecto
def concatenar(*datos: str, separador = " | "):
    return separador.join(datos)

print(concatenar('1','2','3','4','5'))
print(concatenar('1','2','3','4','5', separador=", "))
print(concatenar('1','2','3','4','5', separador=" - "))
print(concatenar('1','2','3','4','5', " - "))  # 1 | 2 | 3 | 4 | 5 |  - 

# No se puede intercambiar el orden con keywords
#print(concatenar(separador=" - ", datos=('1','2','3','4','5')))  # ERROR