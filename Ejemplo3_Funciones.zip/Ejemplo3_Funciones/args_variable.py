# Funcion con numero variable de argumentos
def sumar(*numeros):
    #print(type(numeros)) # <class 'tuple'>
    suma = 0
    for num in numeros:
        suma += num
    return suma
    
print(sumar())
print(sumar(9))
print(sumar(9, 4))
print(sumar(9, 4, 7))
print(sumar(9, 4, 7, 2))


'''
    crear una funcion que recibe el nombre y las notas del alumno
    cada alumno esta matriculado en diferentes asignaturas (2, 4, 1)
    utilizando la funcion sumar() calcular la nota media
    devolver el nombre en mayusculas y la nota media
'''

# Si la funcion tiene un argumento obligatorio, el numero variable de argumentos al final
def procesar_notas(nombre, *notas):
    # sumar(notas) estoy enviando una tupla de datos
    # sumar(*notas) estoy enviando los elementos de la tupla
    nota_media = sumar(*notas) / len(notas)
    # round(que?, num_digitos)
    return nombre.upper(), round(nota_media, 2) 

print(procesar_notas("Juan", 2,5,3))
print(procesar_notas("Maria", 9,8))
print(procesar_notas("Pedro", 7,5,9,6))
print(procesar_notas("Lucia", 10, 8, 9))

# print(procesar_notas(10, 8, 9, "Lucia")) # ERROR
# print(procesar_notas(10, 8, 9, nombre = "Lucia"))  # ERROR
# print(procesar_notas(notas = (10, 8, 9), nombre = "Lucia"))  # ERROR

'''
No se pueden tener 2 argumentos con numero variable
def prueba(*tupla1, *tupla2):
    print(tupla1)
    print(tupla2)
    
prueba(1,2,3,4,5,6)
'''

# Pero si podemos recibir 2 tuplas como argumentos
def prueba(tupla1, tupla2):
    print(tupla1)
    print(tupla2)
    
prueba( (1,2,3) , (4,5,6)  )