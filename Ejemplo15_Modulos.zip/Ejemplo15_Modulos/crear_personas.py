# 1ª forma: importar el modulo completo
import persona

luis = persona.Persona("Luis", 48)  # modulo.recurso
print(luis)


# 2ª forma: importar el modulo completo con alias
import persona as ps

marta = ps.Persona("Marta", 52)   # alias.recurso
print(marta)


# 3ª forma: importar el recurso de un modulo
from persona import Persona

juan = Persona("Juan", 28)   # recurso
print(juan)


# 4ª forma: importar el recurso de un modulo con alias
from persona import Persona as Pers

adolfo = Pers("Adolfo", 61)   # alias
print(adolfo)