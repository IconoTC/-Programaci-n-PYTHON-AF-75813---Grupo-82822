# Abrir el fichero en modo lectura
fichero = open("Ejemplo11_Fichero_Texto/fichero.txt", "rt", encoding="utf-8")

# Leer todo el contenido del fichero
texto = fichero.read()
print(texto)

# Leer todo el contenido del fichero y lo proceso linea a linea
# mover el puntero o cursor al primer caracter
fichero.seek(0)
lista = fichero.readlines()
for linea in lista:
    print(linea.upper(), end="")
    
# leer los primeros 3 caracteres
fichero.seek(0)
caracteres = fichero.readline(3)
print(caracteres)

# Crear una lista con el contenido del fichero
fichero.seek(0)
lista = list(fichero)
for linea in lista:
    print(linea.upper(), end="")
    
# cerrar el fichero
fichero.close()