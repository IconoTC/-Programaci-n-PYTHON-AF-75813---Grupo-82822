'''
    El usuario introduce una letra (l,m,x,j,v,s,d)
    Mostrar el dia de la semana correspondiente
    o "Dia no valido" si no es correcto
    Puede ser que la letra introducida sea minuscula o mayuscula
    Ideas: or, upper(), lower(), in
''' 

letra = input("Introduce una letra (l,m,x,j,v,s,d): ")

match letra:
    case 'l' | 'L':
        print("Es lunes")
    case 'm' | 'M':
        print("Es martes")
    case 'x' | 'X':
        print("Es miercoles")
    case 'j' | 'J':
        print("Es jueves")
    case 'v' | 'V':
        print("Es viernes")
    case 's' | 'S':
        print("Es sabado")
    case 'd' | 'D':
        print("Es domingo")
    case _:
        print("Dia no es valido")
