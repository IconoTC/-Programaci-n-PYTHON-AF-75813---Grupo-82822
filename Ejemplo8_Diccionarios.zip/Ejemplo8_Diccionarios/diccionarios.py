# Diccionarios: los elementos son clave:valor
# No tenemos indices, se accede a través de la clave
# A partir de la version 3.7 se garantiza el orden en entrada
# Las claves no se pueden repetir, se sobreescribe el valor
# Los valores si se pueden repetir
# Se crean con {}

# Si repito la clave, se sobreescribe el valor
alumnos = {'Juan': 6.4, 'Maria':8.3, 'Adolfo':7.1, 'Maria':9.3}
print(alumnos)
print(type(alumnos))  # <class 'dict'>

# Crear un diccionario vacio
vacio = {}
vacio = dict()

# Mostrar las claves: nombres de los alumnos
print(alumnos.keys())  # dict_keys(['Juan', 'Maria', 'Adolfo'])

# Mostrar los values: notas de los alumnos
print(alumnos.values())  # dict_values([6.4, 9.3, 7.1])

# Mostrar los items
print(alumnos.items()) # dict_items([('Juan', 6.4), ('Maria', 9.3), ('Adolfo', 7.1)])

# Operadores de pertenencia: in y not in
print("Maria" in alumnos)

# Acceso a los elementos por clave
#print("Nota de Luis:", alumnos['Luis'])  # KeyError: 'Luis' si no existe la clave genera ERROR
print("Nota de Juan:", alumnos['Juan'])

print("Nota de Luis:", alumnos.get('Luis')) # None
print("Nota de Juan:", alumnos.get('Juan')) 

# Borrar un elemento
del alumnos['Adolfo']   # Si no existe esa clave genera KeyError
print(alumnos)

# Agregar nuevo elemento
alumnos['Pepito'] = 3.5
print(alumnos)

# Modificar un elemento
alumnos['Pepito'] = 5
print(alumnos)

# Otra forma de agregar elementos al diccionario
alumnos.update({'Tomas': 8})
print(alumnos)

# Otra forma de eliminar un elemento
alumnos.__delitem__('Tomas')
print(alumnos)

# Recorrer un diccionario
for alum in alumnos:   # solo me devuelve las claves
    print(alum, alumnos[alum])
    
for alum in alumnos.items(): # cada alum es una tupla
    print(alum)
    
for clave, valor in alumnos.items():
    print(clave, ":", valor)
    
# Otras formas de crear diccionarios
alumnos = dict(Juan=6.4, Maria=8.3, Adolfo=7.1)
alumnos = dict( [ ('Juan',6.4), ('Maria',8.3), ('Adolfo',7.1) ] ) 