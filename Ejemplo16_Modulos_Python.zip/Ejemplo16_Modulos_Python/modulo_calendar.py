import calendar
import locale

# Mostrar el calendario de 2025
print(calendar.calendar(2025, m=4))

# Mostrar el calendario de Julio de 2025
print(calendar.month(2025, 7))

# Calendario que comience en domingo
calendar.setfirstweekday(6) # lunes es 0
print(calendar.month(2025, 7))

# Los dias de la semana
print(calendar.weekheader(1))
print(calendar.weekheader(2))
print(calendar.weekheader(3))

# Saber si un año es bisiesto
print("2024 es bisiesto", calendar.isleap(2024))  # True
print("2025 es bisiesto", calendar.isleap(2025))  # False

# A partir del modulo locale podemos poner el calendario es Español
l_spain = locale.setlocale(locale.LC_ALL, "es_ES")
c_spain = calendar.LocaleTextCalendar(locale=l_spain)
print(c_spain.formatmonth(2025,7))