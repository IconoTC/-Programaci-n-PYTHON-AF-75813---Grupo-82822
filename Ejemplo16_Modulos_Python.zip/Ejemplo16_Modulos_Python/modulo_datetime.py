import datetime

hoy = datetime.date(2025,7,4)
print(hoy)
print(hoy.year)
print(hoy.month)
print(hoy.day)

# Formato personalizado
# https://docs.python.org/es/3/library/datetime.html#format-codes
print(hoy.strftime('%d/%m/%Y'))

print("Dia semana:", hoy.weekday())  # el lunes=0
print("Dia semana:", hoy.isoweekday())  # el lunes=1

print("Fecha  mañana:", hoy.replace(day=5).strftime('%d/%m/%Y'))

print("Fecha y hora actual:", datetime.datetime.now())

# Crear un periodo de tiempo
periodo = datetime.timedelta(days=7)
print(datetime.datetime.today() + periodo)