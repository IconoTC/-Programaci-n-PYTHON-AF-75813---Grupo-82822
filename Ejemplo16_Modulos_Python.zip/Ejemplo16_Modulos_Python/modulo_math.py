import math

print("PI:", math.pi)
print("E:", math.e)
print("SENO:", math.sin(math.radians(90)))
print("COSENO:", math.cos(math.radians(90)))

print("log base 10:", math.log(12345.567, 10))
print("log base 10:", math.log10(12345.567))
print("log base 2:", math.log(12345.567, 2))
print("log base 2:", math.log2(12345.567))

print("2 elevado a 8:", math.pow(2,8))
print("2 elevado a 8:", 2 ** 8)
print("e elevado a 8:", math.exp(8))

print("redondeo al alza 3.89:", math.ceil(3.89))  # 4
print("redondeo al alza 3.19:", math.ceil(3.19))  # 4
print("redondeo a la baja 3.89:", math.floor(3.89))  # 3
print("redondeo a la baja 3.19:", math.floor(3.19))  # 3
print("redondeo a la baja -3.89:", math.floor(-3.89))  # -4
print("redondeo a la baja -3.19:", math.floor(-3.19))  # -4

print("truncar 3.89:", math.trunc(3.89))  # 3
print("truncar 3.19:", math.trunc(3.19))  # 3
print("truncar -3.89:", math.trunc(-3.89))  # -3
print("truncar -3.19:", math.trunc(-3.19))  # -3

print("factorial de 4:", math.factorial(4))