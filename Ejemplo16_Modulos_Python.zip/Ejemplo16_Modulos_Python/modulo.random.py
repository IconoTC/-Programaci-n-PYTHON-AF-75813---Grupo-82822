import random

# genera un numero aleatorio entre 0 y 1 (pero sin llegar a 1)
print(random.random())

# generar un numero aleatorio entero entre un rango de numeros (el ultimo esta excluido)
print("Numero entre 0 y 50:", random.randrange(50)) # 50 esta excluido
print("Numero entre 10 y 50:", random.randrange(10,50))
print("Numero par entre 10 y 50:", random.randrange(10,50,2))

# randint (si incluye el ultimo)
print("Numero entre 0 y 10:", random.randint(0,10))

# con un bucle for sacar 5 numeros aleatorios entre 1 y 6
for item in range(5):
    print("Aleatorio:", random.randint(1,6))
    
    
''' Importante: los metodos randrange y randint pueden devolver numeros repetidos '''
# Generar numeros aleatorios sin duplicados
# choice: retorna UNO aleatorio de la secuencia pasada como argumento (lista o tupla)
# sample: retorna el numero indicado de aleatorios de la secuencia pasada como argumento (lista o tupla)      
print("choice:", random.choice([1,2,3,4,5,6])) 
print("choice:", random.choice((1,2,3,4,5,6))) 
print("sample:", random.sample([1,2,3,4,5,6], 2)) 
print("sample:", random.sample((1,2,3,4,5,6), 2)) 
   