# listas: colecciones ordenadas de elementos (tienen indice)
# en todas las colecciones los elementos pueden ser de diferente tipo
# permite elementos duplicados
# son mutables: permite modificar, agregar, eliminar elementos
# Se crean con []

list1 = ['Maria', 'Perez', 30, 'soltera', 'sin hijos']
list2 = ['estudiante', 'medicina', 28010]
print(list1)

# crear una lista vacia
lista_vacia = []
lista = list()  # invocar al constructor de la clase list

# unir listas
lista = list1 + list2  # el orden es importante
print(lista)
lista = list2 + list1 
print(lista)

# longitud de la lista
print("Longitud:", len(lista))
print("Longitud:", lista.__len__())

# Acceso a los elementos de la lista
# indice en positivo comienza por el primero, por la izquierda
# empezamos en el indice 0
print(lista[2])   # siempre el indice entre [] sea lista, tupla, diccionario

# indice en negativo comienza por el ultimo, por la derecha
# empezamos en el indice -1
print(lista[-2])   # 8 -2 = 6

# Agregar elementos al final -> append
lista.append('morena')
print(lista)

# Agregar elementos en una determinada posicion -> insert
lista.insert(0, 1.70)
print(lista)

# Agregar varios elementos a la vez -> extend   SIEMPRE VAN AL FINAL
lista.extend({1,2,3})   # los elementos han de ir en una coleccion lista, tupla o conjunto
print(lista)

# De forma manual puedo insertar los elementos en la posicion deseada 
'''
datos = (1,2,3)
for idx in range(len(datos)):
    lista.insert(idx, datos[idx])
print(lista)
'''

# Eliminar elementos por posicion
del lista[0]
print(lista)

# Eliminar elementos por busqueda
lista.remove(3)  # busca el elemento 3 y el primero que encuentre lo elimina
print(lista)

# Buscar un elemento y me retorna el indice donde se enecuentra
indice = lista.index('Perez')
print(indice)

# Mostrar cuantas soltera hay
print("Cuantas soltera?", lista.count('soltera'))

# Invertir la lista
lista.reverse()
print(lista)

# Ordenar listas
colores = ['rojo', 'verde', 'azul', 'amarillo']
print(sorted(colores))  # La muestra ordenada pero no la modifica
print(colores)

# Ordena la lista de forma descendente
print(sorted(colores, reverse=True))

# Por defecto, al ser texto lo ordena de forma alfabetica
# Establer el orden, p.e. la longitud de cada elemento
'''
def ordenar(dato):
    return len(dato)
'''
print(sorted(colores, key=lambda dato: len(dato) ))
print(sorted(colores, key=lambda dato: len(dato), reverse=True ))

# Eliminar todos los elementos de la lista
colores.clear()
print(colores)

''' slices [begin:stop:step] '''
# mostrar todos los elementos de la lista
print("Todos:", lista[:])

# mostrar los ultimos 4 elementos
print("Ultimos 4:", lista[-4:])

# Mostrar los elementos del indice 3 al 6
print("Del indice 3 al 6:", lista[3:7])

# Mostrar los elementos del indice 6 al 3
print("Del indice 6 al 3:", lista[6:2])  # saca la lista vacia
print("Del indice 6 al 3:", lista[6:2:-1])

# mostrar todos los elementos de la lista en orden inverso
print("Todos inverso:", lista[::-1])

# mostrar todos los elementos de la lista en orden inverso de 2 en 2
print("Todos inverso de 2 en 2:", lista[::-2])