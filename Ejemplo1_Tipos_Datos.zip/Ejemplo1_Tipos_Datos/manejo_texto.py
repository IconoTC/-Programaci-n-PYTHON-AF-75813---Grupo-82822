texto = "bienvenidos al curso de Python"

print(texto.capitalize())  # Solo la primera letra en mayusculas y el resto en minusculas
print(texto.title())  # Mayuscula la primera letra de cada palabra 
print(texto.upper())  # Todo en mayusculas
print(texto.lower())  # Todo en minusculas
print(texto.swapcase()) # intercambia mayusculas por minusculas y viceversa

print("isalnum", texto.isalnum())  # solo letras y numeros, False por los espacios en blanco
print("isalnum", '12345'.isalnum())  # True
print("isalnum", 'hola'.isalnum())  # True
print("isalnum", 'hola12345'.isalnum()) # True

print("isalpha", texto.isalpha())  # solo letras, False por los espacios en blanco
print("isalpha", '12345'.isalpha())  # False
print("isalpha", 'hola'.isalpha())  # True
print("isalpha", 'hola12345'.isalpha()) # False

print("isdigit", texto.isdigit())  # solo numeros, False por las letras y los espacios en blanco
print("isdigit", '12345'.isdigit())  # True
print("isdigit", 'hola'.isdigit())  # False
print("isdigit", 'hola12345'.isdigit()) # False

print("isupper", texto.isupper())  # solo mayusculas, ignora el resto numeros, espacios en blanco, caracteres especiales, False
print("isupper", '12345'.isupper())  # False
print("isupper", 'hola'.isupper())  # False
print("isupper", 'HOLA12345'.isupper()) # True
print("isupper", 'HOLA 12345'.isupper()) # True
print("isupper", 'HOLA_12345'.isupper()) # True

print("islower", texto.islower())  # solo minusculas, ignora el resto numeros, espacios en blanco, caracteres especiales, False
print("islower", '12345'.islower())  # False
print("islower", 'hola'.islower())  # True
print("islower", 'hola12345'.islower()) # True
print("islower", 'HOLA 12345'.islower()) # False
print("islower", 'hola_12345'.islower()) # True

print("Longitud:", len(texto))  # Numero de caracteres de la cadena de texto

# La tabla ASCII esta ordenada (1º numeros, 2º mayusculas, 3º minusculas)
print("max:", max(texto))  # y   El caracter con mas valor dentro de la tabla ASCII
print("min:", min(texto))  # el espacio en blanco

ejemplo = "     Hoy es lunes     "
print(ejemplo, end=".\n")
print("lstrip", ejemplo.lstrip(), end=".\n")   # Elimina espacios por la izquierda
print("rstrip", ejemplo.rstrip(), end=".\n")   # Elimina espacios por la derecha
print("strip", ejemplo.strip(), end=".\n")   # Elimina espacios por la izquierda y la derecha

print("replace", texto.replace("Python", "Angular"))
print("replace", texto.replace("e", "E"))  # Reemplaza todas
print("replace", texto.replace("e", "E", 1))  # Reemplaza solo la primera

palabras = texto.split()  # Parte la cadena en subcadenas por el espacio en blanco
print(type(palabras))  # palabras es una lista
print(palabras)

# Los indices siempre empiezan en 0
print("find", texto.find("o"))   # 9 Retorna el indice donde encuentra la primera letra o
print("rfind", texto.rfind("o")) # 28, empieza a buscar por la derecha y retorna el indice que primero encuentra
print("find", texto.find("o", 10))  # 19  porque empieza a buscar a partir del indice 10
print("find", texto.find("o", 10, 15))  # -1 porque busca entre el indice 10 y 15 sin incluirlo