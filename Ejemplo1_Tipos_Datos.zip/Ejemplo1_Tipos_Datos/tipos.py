'''
    Comentarios de Bloque (Docstring)
    3 comillas simples o dobles
    Ejemplo de tipos de datso en Python
'''

# numeros enteros  <class 'int'>
numero1 = 8
numero2 = 4
suma = numero1 + numero2
print("Suma:", suma)
print(type(suma))

# TypeError: can only concatenate str (not "int") to str
# La concatenacion en Python solo esta permitida entre cadenas de texto
#print("Suma:" + suma)

# numeros reales  <class 'float'>
base = 4.89
altura = 9.23
triangulo = base * altura / 2
print("Area del triangulo:", triangulo)
print(type(triangulo))

# booleanos: True o False <class 'bool'>
soltero = True
print("Estas soltero?", soltero)
print(type(soltero))

# cadenas de texto <class 'str'>
# se puede utilizar comillas simples o dobles
nombre = "Juan"
apellido = 'Lopez'
print(nombre, apellido)
print(nombre + apellido)
print(type(nombre))

# la funcion print podemos manejar la separacion y el final
print(nombre, apellido, sep="")
print(nombre, apellido, sep="-")
print(nombre, apellido, sep="-", end=".")
print(nombre, apellido, sep="-", end=".\n")