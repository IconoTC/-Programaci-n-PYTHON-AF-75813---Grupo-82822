# Operadores aritmeticos
numero1 = 7
numero2 = 5
print("Division:", numero1 / numero2)
print("Division entera:", numero1 // numero2)
print("Resto o Modulo de la Division:", numero1 % numero2)

# Operadores de asignacion
numero1 += 1      # numero1 = numero1 + 1  

# En Python no existen los incrementos o decrementos
numero1 += 1    # numero1++
numero1 -= 1    # numero1--

# Operadores de comparacion
print(numero2 == 5)  # True
print(numero2 != 5)  # False

# Operadores logicos: and, or, not
print(numero2 == 5 and numero1 > 1) # True
print(numero2 == 5 or numero1 > 10) # True 

# Operadores de identidad (is, is not)
# Sirve para verificar si es el mismo objeto
num1 = 6
num2 = 6
print("Es el mismo objeto", num1 is num2) # True

nombres1 = ['Juan', 'Maria']
nombres2 = ['Juan', 'Maria']
# nombres2 = nombres1  # True porque nombres2 y nombres1 tienen el mismo puntero
print("Es la misma coleccion?", nombres1 is nombres2)  # False porque las direcciones de memoria son distintas
print(nombres1 == nombres2)  # True

# Operadores de pertenencia (in, not in)
print('Luis esta en nombres1', "Luis" in nombres1) # False
print('Luis no esta en nombres1', "Luis" not in nombres1)