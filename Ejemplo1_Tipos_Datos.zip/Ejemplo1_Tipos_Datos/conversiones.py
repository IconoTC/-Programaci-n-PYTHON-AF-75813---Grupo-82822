import math

# convertir de texto a numero entero
dato = input("Introduce un numero: ")
print(type(dato)) # <class 'str'>
numero1 = int(dato)
print(type(numero1)) # <class 'int'>
numero2 = int(input("Introduce otro numero: "))
print("Suma:", numero1 + numero2)
# ValueError: invalid literal for int() with base 10: '10.45'
# int('10.45')
# ValueError: invalid literal for int() with base 10: 'dos'
# int('dos')

# convertir de texto a numero real
radio = float(input("Introduce radio del circulo: "))
print("Area del circulo:", math.pi * math.pow(radio, 2))
print("Area del circulo:", math.pi * radio ** 2) # ** potencia
# float(45)   funciona sin problema

# convertir numero a booleano
# 0 -> False, 1 -> True
# Este es el unico caso que convierte a False (0 o ''), todo lo demas es True
soltero = ''
print("Estas soltero?", bool(soltero))

# convertir a texto
print(numero1 + numero2)
print( str(numero1) + str(numero2))

# con shift + enter ejecuta el codigo seleccionado
print(7 + True)  # conversion automatica o implicita